import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
from torch_geometric.utils import negative_sampling
from sklearn.metrics.pairwise import rbf_kernel
from torch.autograd import Function

import torch
from torch import nn
import torch.nn.functional as F
from torch_geometric.nn import MessagePassing
from torch.autograd import Function
from torch_geometric.nn.dense.linear import Linear
from torch_geometric.nn.conv.gcn_conv import gcn_norm
from torch_sparse import SparseTensor
import torch_geometric.nn as pyg_nn
from torch import Tensor
from torch.nn import Parameter
from torch_sparse import SparseTensor
from typing import Optional
from torch_geometric.nn.conv import MessagePassing
from torch_geometric.nn.inits import zeros
from torch_geometric.typing import Adj, OptPairTensor, OptTensor
from torch_sparse import matmul as torch_sparse_matmul
from torch_geometric.nn.conv.gcn_conv import gcn_norm

from torch_geometric.nn import GCNConv, GATv2Conv  # or any GNN you like


from torch_geometric.nn.models import GCN, GAT
from scipy.optimize import linear_sum_assignment
from torch_geometric.data import Data

from matplotlib import pyplot as plt
import numpy as np

def spmm(src: Adj, other: Tensor, reduce: str = "sum") -> Tensor:
    """Matrix product of sparse matrix with dense matrix.

    Args:
        src (Tensor or torch_sparse.SparseTensor]): The input sparse matrix,
            either a :class:`torch_sparse.SparseTensor` or a
            :class:`torch.sparse.Tensor`.
        other (Tensor): The input dense matrix.
        reduce (str, optional): The reduce operation to use
            (:obj:`"sum"`, :obj:`"mean"`, :obj:`"min"`, :obj:`"max"`).
            (default: :obj:`"sum"`)

    :rtype: :class:`Tensor`
    """
    assert reduce in ['sum', 'add', 'mean', 'min', 'max']

    if isinstance(src, SparseTensor):
        return torch_sparse_matmul(src, other, reduce)

    if reduce in ['sum', 'add']:
        return torch.sparse.mm(src, other)

    # TODO: Support `mean` reduction for PyTorch SparseTensor
    raise ValueError(f"`{reduce}` reduction is not supported for "
                     f"`torch.sparse.Tensor`.")


class GCN_reweight(MessagePassing):
    r"""The graph convolutional operator from the `"Semi-supervised
    Classification with Graph Convolutional Networks"
    <https://arxiv.org/abs/1609.02907>`_ paper

    .. math::
        \mathbf{X}^{\prime} = \mathbf{\hat{D}}^{-1/2} \mathbf{\hat{A}}
        \mathbf{\hat{D}}^{-1/2} \mathbf{X} \mathbf{\Theta},

    where :math:`\mathbf{\hat{A}} = \mathbf{A} + \mathbf{I}` denotes the
    adjacency matrix with inserted self-loops and
    :math:`\hat{D}_{ii} = \sum_{j=0} \hat{A}_{ij}` its diagonal degree matrix.
    The adjacency matrix can include other values than :obj:`1` representing
    edge weights via the optional :obj:`edge_weight` tensor.

    Its node-wise formulation is given by:

    .. math::
        \mathbf{x}^{\prime}_i = \mathbf{\Theta}^{\top} \sum_{j \in
        \mathcal{N}(v) \cup \{ i \}} \frac{e_{j,i}}{\sqrt{\hat{d}_j
        \hat{d}_i}} \mathbf{x}_j

    with :math:`\hat{d}_i = 1 + \sum_{j \in \mathcal{N}(i)} e_{j,i}`, where
    :math:`e_{j,i}` denotes the edge weight from source node :obj:`j` to target
    node :obj:`i` (default: :obj:`1.0`)

    Args:
        in_channels (int): Size of each input sample, or :obj:`-1` to derive
            the size from the first input(s) to the forward method.
        out_channels (int): Size of each output sample.
        improved (bool, optional): If set to :obj:`True`, the layer computes
            :math:`\mathbf{\hat{A}}` as :math:`\mathbf{A} + 2\mathbf{I}`.
            (default: :obj:`False`)
        cached (bool, optional): If set to :obj:`True`, the layer will cache
            the computation of :math:`\mathbf{\hat{D}}^{-1/2} \mathbf{\hat{A}}
            \mathbf{\hat{D}}^{-1/2}` on first execution, and will use the
            cached version for further executions.
            This parameter should only be set to :obj:`True` in transductive
            learning scenarios. (default: :obj:`False`)
        add_self_loops (bool, optional): If set to :obj:`False`, will not add
            self-loops to the input graph. (default: :obj:`True`)
        normalize (bool, optional): Whether to add self-loops and compute
            symmetric normalization coefficients on the fly.
            (default: :obj:`True`)
        bias (bool, optional): If set to :obj:`False`, the layer will not learn
            an additive bias. (default: :obj:`True`)
        **kwargs (optional): Additional arguments of
            :class:`torch_geometric.nn.conv.MessagePassing`.

    Shapes:
        - **input:**
          node features :math:`(|\mathcal{V}|, F_{in})`,
          edge indices :math:`(2, |\mathcal{E}|)`,
          edge weights :math:`(|\mathcal{E}|)` *(optional)*
        - **output:** node features :math:`(|\mathcal{V}|, F_{out})`
    """

    _cached_edge_index: Optional[OptPairTensor]
    _cached_adj_t: Optional[SparseTensor]

    def __init__(self, in_channels: int, out_channels: int, aggr: str,
                 improved: bool = False, cached: bool = False,
                 add_self_loops: bool = False, normalize: bool = True,
                 bias: bool = True, **kwargs):

        kwargs.setdefault('aggr', "add")
        super().__init__(**kwargs, flow ="target_to_source")

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.improved = improved
        self.cached = cached
        self.add_self_loops = add_self_loops
        if aggr == "add":
            self.normalize = False
        else:
            self.normalize = True
        #self.normalize = normalize

        self._cached_edge_index = None
        self._cached_adj_t = None

        self.lin = Linear(in_channels, out_channels, bias=False,
                          weight_initializer='glorot')


        if bias:
            self.bias = Parameter(torch.Tensor(out_channels))
        else:
            self.register_parameter('bias', None)

        self.reset_parameters()

    def reset_parameters(self):
        self.lin.reset_parameters()
        zeros(self.bias)
        self._cached_edge_index = None
        self._cached_adj_t = None


    def forward(self, x: Tensor, edge_index: Adj,
                edge_weight: OptTensor=None, lmda=1) -> Tensor:
        """"""
        # lmda = 1

        edge_rw = edge_weight
        edge_weight = torch.ones_like(edge_rw)

        # print(f"{edge_weight.shape} {edge_index.shape}")
        #edge_weight = None
        if self.normalize:
            if isinstance(edge_index, Tensor):
                cache = self._cached_edge_index
                if cache is None:
                    # print(f"check GCN: {edge_index.device} {edge_weight.device}")
                    edge_index, edge_weight = gcn_norm(  # yapf: disable
                        edge_index, edge_weight, x.size(self.node_dim),
                        self.improved, self.add_self_loops, dtype=x.dtype)
                    if self.cached:
                        self._cached_edge_index = (edge_index, edge_weight)
                else:
                    edge_index, edge_weight = cache[0], cache[1]

            elif isinstance(edge_index, SparseTensor):
                cache = self._cached_adj_t
                if cache is None:
                    edge_index = gcn_norm(  # yapf: disable
                        edge_index, edge_weight, x.size(self.node_dim),
                        self.improved, self.add_self_loops, x.dtype)
                    if self.cached:
                        self._cached_adj_t = edge_index
                else:
                    edge_index = cache

        x = self.lin(x)

        # propagate_type: (x: Tensor, edge_weight: OptTensor, lmda: int, edge_rw: OptTensor)
        out = self.propagate(edge_index=edge_index, x=x, edge_weight=edge_weight,
                             size=None, lmda=lmda, edge_rw=edge_rw)

        if self.bias is not None:
            out = out + self.bias

        return out

    def message(self, x_j: Tensor, edge_weight: OptTensor, lmda, edge_rw) -> Tensor:
        x_j = (edge_weight.view(-1, 1) * x_j)
        x_j = (1-lmda) * x_j + (lmda) * (edge_rw.view(-1, 1) * x_j)
        return x_j

    def message_and_aggregate(self, adj_t: SparseTensor, x: Tensor) -> Tensor:
        return spmm(adj_t, x, reduce=self.aggr)




class GradientReversalFunction(Function):
    @staticmethod
    def forward(ctx, x, lambda_factor):
        ctx.lambda_factor = lambda_factor
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output):
        lambda_factor = ctx.lambda_factor
        return grad_output.neg() * lambda_factor, None

class GradientReversal(nn.Module):
    def __init__(self, lambda_factor=1.0):
        super().__init__()
        self.lambda_factor = lambda_factor

    def forward(self, x):
        return GradientReversalFunction.apply(x, self.lambda_factor)

class CrossDomainLinkPredictor(nn.Module):
    def __init__(self, in_dim, hid_dim=300, out_dim=64, grl_lambda=1.0):
        super().__init__()
        # self.gnn_s = GCNConv(in_dim, hid_dim)
        self.gnn_s = GAT(in_channels=in_dim, hidden_channels=hid_dim, num_layers=3, out_channels=hid_dim)
        self.proj_s = nn.Linear(hid_dim, out_dim)

        # self.gnn_t = GCNConv(in_dim, hid_dim)
        self.gnn_t = GAT(in_channels=in_dim, hidden_channels=hid_dim, num_layers=3, out_channels=hid_dim)
        self.proj_t = nn.Linear(hid_dim, out_dim)


        self.edge_mlp = nn.Sequential(
            nn.Linear(out_dim*4, 64),
            nn.ReLU(),
            nn.Linear(64, 1)
        )

        self.domain_discriminator = nn.Sequential(
            GradientReversal(lambda_factor=grl_lambda),
            nn.Linear(out_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 1)  # 输出 logit，sigmoid 后为 P(domain=target)
        )

        self.grl_lambda = grl_lambda

    def encode(self, x, edge_index, domain):
        if domain == 'source':
            h = F.relu(self.gnn_s(x, edge_index))
            return self.proj_s(h)  # [N, out_dim]
        elif domain == 'target':
            h = F.relu(self.gnn_t(x, edge_index))
            return self.proj_t(h)  # [N, out_dim]


    # def decode_edge_feat(self, z_i, z_j):
    #     return z_i * z_j  # Hadamard product, shape: [B, out_dim]

    def decode_edge_feat(self, z_i, z_j):
        return torch.cat([z_i, z_j, z_i * z_j, z_i - z_j], dim=-1)

    def decode_score(self, edge_feat):
        # 从边特征预测存在概率（logit）
        return self.edge_mlp(edge_feat).squeeze(-1)  # [B]

    def discriminate_domain(self, z):
        return self.domain_discriminator(z).squeeze(-1)  # [N]


class CrossNetwork(torch.nn.Module):
    def __init__(self, in_dim, out_dim, device, args, grl_lambda=1.0):
        super().__init__()
        self.args = args
        self.cross_flag = True
        self.device = device

        # self.edge_num = args.edge_num


        if args.encoder_type == 'GCN':
            self.encoder = GCN(in_channels=in_dim, hidden_channels=500, num_layers=2, out_channels=args.encoder_dim)
        elif args.encoder_type == 'GAT':
            self.encoder = GAT(in_channels=in_dim, hidden_channels=500, num_layers=2, out_channels=args.encoder_dim)

        self.edge_weight_new = nn.Parameter(torch.full((args.new_edge_num,), args.new_edge_init_weight).to(self.device))

        # self.prop_input = GCN(args.encoder_dim, args.gnn_dim, 1)
        # self.prop_hidden = GCN(args.gnn_dim, args.gnn_dim, 2)
        self.prop_input = GCN_reweight(args.encoder_dim, args.gnn_dim, args.pooling)
        self.prop_hidden = GCN_reweight(args.gnn_dim, args.gnn_dim, args.pooling)



        self.dropout = args.dropout
        self.bn = args.bn
        # self.store_cross_edges = 0

        # conv layers
        self.conv = nn.ModuleList()
        self.conv.append(self.prop_input)
        for i in range(args.gnn_layers - 1):
            self.conv.append(self.prop_hidden)

        #bn layers
        self.bns = nn.ModuleList()
        for i in range(args.gnn_layers - 1):
            self.bns.append(nn.BatchNorm1d(args.gnn_dim))
        self.bn_mlp = nn.BatchNorm1d(args.cls_dim)

        # classification layer
        self.mlp_classify = nn.ModuleList()

        if args.cls_layers == 1:
            self.mlp_classify.append(nn.Linear(args.gnn_dim, out_dim))


        else:
            self.mlp_classify.append(nn.Linear(args.gnn_dim, args.cls_dim))
            for i in range(args.cls_layers - 2):
                self.mlp_classify.append(nn.Linear(args.cls_dim, args.cls_dim))
            self.mlp_classify.append(nn.Linear(args.cls_dim, out_dim))

        self.domain_discriminator = nn.Sequential(
            GradientReversal(lambda_factor=grl_lambda),
            nn.Linear(self.args.gnn_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 1)  # 输出 logit，sigmoid 后为 P(domain=target)
        )

        self.grl_lambda = grl_lambda

    def _inv_sigmoid(self, x, eps=1e-6):
        """将 [0,2] 内的标量或张量 x 反变换到 sigmoid 输入空间"""
        x = torch.as_tensor(x, dtype=torch.float32, device=self.edge_weight_raw.device)
        x_norm = torch.clamp(x / 2.0, eps, 1 - eps)  # 归一化到 (eps, 1-eps)
        return torch.log(x_norm / (1 - x_norm))


    def reset_new_edge_weights(self):
        # self.edge_weight_new = nn.Parameter(torch.full((self.args.new_edge_num,), self.args.new_edge_init_weight).to(self.device))
        self.edge_weight_new.data.fill_(self.args.new_edge_init_weight)


    def forward(self, x, edge_index, edge_weight, phase):
        if phase == "source":
            total_edge_weight = torch.cat([edge_weight, self.edge_weight_new], dim=0)  # [E_total]
            # print(f"new edge weight: {self.edge_weight_new.shape} {self.edge_weight_new}")
        else:
            total_edge_weight = edge_weight

        embedding = self.encoder(x, edge_index, total_edge_weight)

        for i, layer in enumerate(self.conv):

            embedding = layer(embedding, edge_index, edge_weight=total_edge_weight)

            # if self.bn and (i != len(self.conv) - 1):
            #     x = self.bns[i](x)
            embedding = F.relu(embedding)
            embedding = F.dropout(embedding, p=self.dropout)

            #---------dual module----------
            #
            # # if self.bn and (i != len(self.conv) - 1):
            # #     x = self.bns[i](x)
            # tgt_x = F.relu(tgt_x)
            # tgt_x = F.dropout(tgt_x, p=self.dropout)
        # print(f"embedding: {type(embedding)} {embedding.shape}")
        pred_alone = embedding


        for i in range(len(self.mlp_classify)):
            # print(f"mlp_classify: {i}")
            pred_alone = self.mlp_classify[i](pred_alone)
            if i != (len(self.mlp_classify) - 1):
                if self.bn:
                    pred_alone = self.bn_mlp(pred_alone)
                pred_alone = F.relu(pred_alone)
            #y = F.dropout(y, p=self.dropout)
        # print(f"pred_alone: {type(pred_alone)} {pred_alone.shape}")

        return embedding, pred_alone



