import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
from torch_geometric.utils import negative_sampling
from sklearn.metrics.pairwise import rbf_kernel
import data_process.pre_datasets as pre_datasets
import argparse
from model_v4 import CrossDomainLinkPredictor, CrossNetwork
import torch.optim as optim
import utils
from sklearn.metrics import roc_auc_score, accuracy_score, f1_score, confusion_matrix
import random
import numpy as np
import pickle

def CE_loss(pred, label):
    label = label.type(torch.int64)
    loss = nn.CrossEntropyLoss()
    return loss(pred, label)


def arg_parse():
    parser = argparse.ArgumentParser(description='arguments')

    parser.add_argument('--cls_layers', type=int, help='Number of classification layers', default=2)
    parser.add_argument('--gnn_layers', type=int, help='Number of GNN layers', default=3)
    parser.add_argument('--gnn_dim', type=int, help='hidden dimension for GNN', default=300)
    # parser.add_argument('--dc_layers', type=int, help='domain classifier layers', default=3)
    parser.add_argument('--cls_dim', type=int, help='hidden dimension for classification layer', default=300)
    parser.add_argument('--pooling', type=str, help='pooling method in the GNN conv: add or mean', default="mean")
    parser.add_argument('--bn', type=bool, help='if batch norm in GNN', default=False)
    parser.add_argument('--valid_data', type=str,help='specify the validation dataset to select model', default="tgt")
    parser.add_argument('--gnn_dc', type=bool,help='if we want to add adversarial alignment for the GNN', default=False)
    parser.add_argument('--epochs', type=int, help='Number of training epochs', default=300)
    parser.add_argument('--opt', type=str, help='optimizer', default='adam')
    parser.add_argument('--opt_scheduler', type=str, help='optimizer scheduler', default='step')
    parser.add_argument('--opt_decay_step', type=int, default=30)
    parser.add_argument('--opt_decay_rate', type=int, default=0.9)
    parser.add_argument('--dropout', type=float, default=0.5)
    parser.add_argument('--weight_decay', type=float, default=0)
    parser.add_argument('--lr', type=float, help='Learning rate', default=0.003)
    parser.add_argument('--new_edge_lr', type=float, help='Learning rate', default=0.05)
    parser.add_argument('--ep_lr', type=float, help='Edge Predictor Learning rate', default=0.005)
    parser.add_argument("--dir_name", type=str, help='specify the directory name', default="debug")
    parser.add_argument("--dataset", type=str, help='specify the dataset', default='DBLP_ACM')
    parser.add_argument("--src_name", type=str, help='specify for the source dataset name', default='dblp')
    parser.add_argument("--tgt_name", type=str, help='specify for the target dataset name', default='acm')


    parser.add_argument('--encoder_type', type=str, help='first encoder type', default="GAT")
    parser.add_argument('--encoder_dim', type=int, help='first encoder dim', default=128)


    parser.add_argument("--reset_edges_frequency", type=int, help='reset_edges_frequency', default=10)
    parser.add_argument('--new_edge_num', type=int, help='Number of new build edge', default=6000)
    parser.add_argument('--new_edge_init_weight', type=float, help='Number of new build edge', default=1.0)

    parser.add_argument('--start_pseudo_optim_epoch', type=int, help='Epoch of start add pseudo-label', default=150)
    parser.add_argument('--lambda_pseudo', type=float, help='co-efficient pseudo-label loss', default=0.8)

    parser.add_argument('--gumbel_tau', type=float, help='gumbel-softmax tau ', default=0.5)
    parser.add_argument('--pseudo_conf_threshold', type=float, help='pseudo_conf_threshold', default=0.9)


    return parser.parse_args()


def compute_mmd(X, Y, kernel_scale=1.0):
    N, D = X.shape
    M = Y.shape[0]

    # Compute pairwise distances
    XX = torch.cdist(X, X, p=2)  # [N, N]
    YY = torch.cdist(Y, Y, p=2)  # [M, M]
    XY = torch.cdist(X, Y, p=2)  # [N, M]

    # Median heuristic for bandwidth (optional)
    # Here we fix scale for simplicity
    sigma = kernel_scale

    K_XX = torch.exp(-XX ** 2 / (2 * sigma ** 2))
    K_YY = torch.exp(-YY ** 2 / (2 * sigma ** 2))
    K_XY = torch.exp(-XY ** 2 / (2 * sigma ** 2))

    mmd = K_XX.mean() + K_YY.mean() - 2 * K_XY.mean()
    return mmd



def train_ep_step(model, optimizer, scheduler,
               xs, edge_index_s,
               xt, edge_index_t,
               device):
    model.train()
    optimizer.zero_grad()

    zs = model.encode(xs.to(device), edge_index_s.to(device), 'source')  # [Ns, d]
    zt = model.encode(xt.to(device), edge_index_t.to(device), 'source')  # [Nt, d]


    pos_edge_index_t = edge_index_t  # existing edges in target domain
    src_t, dst_t = pos_edge_index_t
    edge_feat_Q = model.decode_edge_feat(zt[src_t], zt[dst_t])  # [E_t, d]

    Ns, Nt = zs.size(0), zt.size(0)


    pos_edge_index_s = edge_index_s  # existing edges in target domain
    src_s, dst_s = pos_edge_index_s
    edge_feat_Qprime = model.decode_edge_feat(zs[src_s], zs[dst_s])  # [E_t, d]

    # edge_feat_Qprime = model.decode_edge_feat(zs[idx_s], zt[idx_t])  # [S, d]
    # loss_align = compute_mmd(edge_feat_Q.detach(), edge_feat_Qprime)

    # Optional: add reconstruction loss on within-domain edges (self-supervision)
    # This helps GNN learn meaningful embeddings
    pos_scores_s = model.decode_score(model.decode_edge_feat(zs[edge_index_s[0]], zs[edge_index_s[1]]))
    neg_edge_s = negative_sampling(edge_index_s, num_nodes=Ns, num_neg_samples=edge_index_s.size(1))
    neg_scores_s = model.decode_score(model.decode_edge_feat(zs[neg_edge_s[0]], zs[neg_edge_s[1]]))
    loss_recon_s = F.binary_cross_entropy_with_logits(
        torch.cat([pos_scores_s, neg_scores_s]),
        torch.cat([torch.ones_like(pos_scores_s), torch.zeros_like(neg_scores_s)])
    )

    pos_scores_t = model.decode_score(model.decode_edge_feat(zt[edge_index_t[0]], zt[edge_index_t[1]]))
    neg_edge_t = negative_sampling(edge_index_t, num_nodes=Nt, num_neg_samples=edge_index_t.size(1))
    neg_scores_t = model.decode_score(model.decode_edge_feat(zt[neg_edge_t[0]], zt[neg_edge_t[1]]))
    loss_recon_t = F.binary_cross_entropy_with_logits(
        torch.cat([pos_scores_t, neg_scores_t]),
        torch.cat([torch.ones_like(pos_scores_t), torch.zeros_like(neg_scores_t)])
    )

    total_loss = loss_recon_s + loss_recon_t


    total_loss.backward()
    optimizer.step()
    scheduler.step()

    return total_loss.item(), zs, zt

def train_model_step(model, optimizer, scheduler, src_dataset, tgt_dataset, device, epoch, args):
    model.train()

    src_x = src_dataset.x
    src_edge_index = src_dataset.edge_index
    src_edge_weight = src_dataset.edge_weight

    tgt_x = tgt_dataset.x
    tgt_edge_index = tgt_dataset.edge_index
    tgt_edge_weight = tgt_dataset.edge_weight

    src_emd, src_pred = model(src_x, src_edge_index, src_edge_weight, "source")
    tgt_emd, tgt_pred = model(tgt_x, tgt_edge_index, tgt_edge_weight, "target")


    pred_source_training = src_pred[src_dataset.source_training_mask]
    pred_source_validation = src_pred[src_dataset.source_validation_mask]
    pred_source_testing = src_pred[src_dataset.source_testing_mask]

    label_source_training = src_dataset.y[src_dataset.source_training_mask]
    label_source_validation = src_dataset.y[src_dataset.source_validation_mask]
    label_source_testing = src_dataset.y[src_dataset.source_testing_mask]

    eps = 1e-8
    src_pred_probs = F.softmax(src_pred, dim=1)
    tgt_pred_probs = F.softmax(tgt_pred, dim=1)


    mean_src = torch.mean(src_pred_probs, dim=0)  # [C]
    mean_tgt = torch.mean(tgt_pred_probs, dim=0)  # [C]

    # Add epsilon for numerical stability (avoid log(0))
    mean_src = mean_src + eps
    mean_tgt = mean_tgt + eps

    # Re-normalize to ensure they sum to 1 (optional but safe)
    mean_src = mean_src / mean_src.sum()
    mean_tgt = mean_tgt / mean_tgt.sum()

    # KL(Q_tgt || Q_src) — commonly used direction
    kl_loss = F.kl_div(
        input=mean_tgt.log(),  # log-probabilities of "target" distribution
        target=mean_src,  # "source" as reference distribution
        reduction='sum'  # returns scalar
    )

    pseudo_label_loss = torch.tensor(0.0, device=device)

    if epoch > args.start_pseudo_optim_epoch:
        if args.lambda_pseudo > 0:
            tau = getattr(args, 'gumbel_tau', 0.5)  # 温度参数，默认 0.5
            gumbel_pseudo_targets = F.gumbel_softmax(tgt_pred, tau=tau, hard=True)  # [N_t, C]
            tgt_confidence = tgt_pred_probs.max(dim=1).values  # [N_t]
            conf_threshold = getattr(args, 'pseudo_conf_threshold', 0.9)
            high_conf_mask = tgt_confidence > conf_threshold  # [N_t], bool

            if high_conf_mask.any():
                log_probs_tgt = F.log_softmax(tgt_pred[high_conf_mask], dim=1)  # [M, C]
                pseudo_targets_selected = gumbel_pseudo_targets[high_conf_mask]  # [M, C]

                pseudo_label_loss = -(pseudo_targets_selected * log_probs_tgt).sum(dim=1).mean()
            else:
                pseudo_label_loss = torch.tensor(0.0, device=device)

    source_loss = CE_loss(pred_source_training, label_source_training)
    total_loss = source_loss



    optimizer.zero_grad()
    total_loss.backward()
    optimizer.step()
    scheduler.step()

    return total_loss.item(), source_loss.item(), kl_loss.item(), pseudo_label_loss.item()

def eval_model_step(model, optimizer, scheduler, src_dataset, tgt_dataset, device, args):
    model.eval()
    print(f"model eval")
    label_source_training = src_dataset.y[src_dataset.source_training_mask]
    label_source_validation = src_dataset.y[src_dataset.source_validation_mask]
    label_source_testing = src_dataset.y[src_dataset.source_testing_mask]
    label_target_validation = tgt_dataset.y[tgt_dataset.target_validation_mask]
    label_target_testing = tgt_dataset.y[tgt_dataset.target_testing_mask]


    with torch.no_grad():
        _, pred_src = model(src_dataset.x, src_dataset.edge_index, src_dataset.edge_weight, "source")
        _, pred_tgt = model(tgt_dataset.x, tgt_dataset.edge_index, tgt_dataset.edge_weight, "target")

        pred_source_training = pred_src[src_dataset.source_training_mask]
        pred_source_validation = pred_src[src_dataset.source_validation_mask]
        pred_source_testing = pred_src[src_dataset.source_testing_mask]
        pred_target_validation = pred_tgt[tgt_dataset.target_validation_mask]
        pred_target_testing = pred_tgt[tgt_dataset.target_testing_mask]

        acc_src_training = get_acc_score(pred_source_training, label_source_training, args.dataset)
        acc_src_validation = get_acc_score(pred_source_validation, label_source_validation, args.dataset)
        acc_src_testing = get_acc_score(pred_source_testing, label_source_testing, args.dataset)
        acc_target_validation = get_acc_score(pred_target_validation, label_target_validation, args.dataset)
        acc_target_testing = get_acc_score(pred_target_testing, label_target_testing, args.dataset)

        return acc_src_training, acc_src_validation, acc_src_testing, acc_target_validation, acc_target_testing



def get_acc_score(pred, label, dataset):
    if dataset == "MAG":
        idx = torch.nonzero(label < len(torch.unique(label)) - 1)
    else:
        idx = torch.arange(label.size(0))
    label = label[idx]
    pred_label = pred.detach().clone()
    pred_label = pred_label.argmax(dim=1)
    pred_label = pred_label[idx]
    acc_score = accuracy_score(label.cpu().detach().numpy(), pred_label.cpu().detach().numpy())

    return acc_score





def train(edge_predictor, edge_predictor_t, model, src_dataset, tgt_dataset, device, opt, scheduler, seed, args):
    np.random.seed(seed)
    torch.manual_seed(seed)
    random.seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.cuda.manual_seed(seed)


    src_dataset, tgt_dataset = src_dataset.to(device), tgt_dataset.to(device)
    origin_src_edge_index = src_dataset.edge_index.clone()
    origin_tgt_edge_index = tgt_dataset.edge_index.clone()
    origin_src_edge_weight = src_dataset.edge_weight.clone()
    origin_tgt_edge_weight = tgt_dataset.edge_weight.clone()

    best_acc_src_training = 0
    best_acc_src_validation = 0
    best_acc_src_testing = 0
    best_acc_target_validation = 0
    best_acc_target_testing = 0
    list_best_acc = [best_acc_src_training, best_acc_src_validation, best_acc_src_testing, best_acc_target_validation, best_acc_target_testing]

    list_acc_src_training = []
    list_acc_src_validation = []
    list_acc_src_testing = []
    list_acc_target_validation = []
    list_acc_target_testing = []
    list_acc = [list_acc_src_training, list_acc_src_validation, list_acc_src_testing, list_acc_target_validation, list_acc_target_testing]

    list_losses = [[], [], [], [], []]
    list_ep_loss = []

    list_total_loss = []

    model.to(device)
    edge_predictor.to(device)
    edge_predictor_t.to(device)

    for e in range(args.epochs):
        print(f"epoch: {e}")
        ep_loss, zs, zt = train_ep_step(edge_predictor, opt, scheduler, src_dataset.x, src_dataset.edge_index, tgt_dataset.x, tgt_dataset.edge_index, device)
        ep_loss_t, zs_t, zt_t = train_ep_step(edge_predictor_t, opt, scheduler, tgt_dataset.x, tgt_dataset.edge_index, src_dataset.x, src_dataset.edge_index, device)


        new_edge_num = args.new_edge_num

        if e % args.reset_edges_frequency == 0:
            model.reset_new_edge_weights()
            src_ids, dst_ids, v = predict_new_links(edge_predictor, zs, zs, new_edge_num)
            new_edge = torch.stack([src_ids, dst_ids], dim=0)
            # print(f"new_edge: {new_edge.shape} {origin_src_edge_index.shape}")
            src_dataset.edge_index = torch.cat((origin_src_edge_index, new_edge), dim=1)
            # src_dataset.edge_weight = torch.cat((origin_src_edge_weight, torch.ones(new_edge_num).to(device)), dim=0)
            # print(f"src_dataset.edge_index: {src_dataset.edge_index.shape}")
            # print(f"src_dataset.edge_weight: {src_dataset.edge_weight.shape}")

            src_ids, dst_ids, v = predict_new_links(edge_predictor_t, zs_t, zs_t, new_edge_num)
            new_edge = torch.stack([src_ids, dst_ids], dim=0)
            tgt_dataset.edge_index = torch.cat((origin_tgt_edge_index, new_edge), dim=1)


        total_loss, source_loss, kl_loss, pseudo_label_loss = train_model_step(model, optimizer, scheduler, src_dataset, tgt_dataset, device, e, args)

        print(f"ep_loss: {ep_loss + ep_loss_t}     total_loss: {total_loss}     source_loss: {source_loss}     kl_loss: {kl_loss}     pseudo_label_loss: {pseudo_label_loss}")
        for i in range(len(list_losses)):
            losses = [total_loss, source_loss, kl_loss, pseudo_label_loss, ep_loss + ep_loss_t]
            list_losses[i].append(losses[i])


        # list_total_loss.append(total_loss)
        # list_ep_loss.append(ep_loss)
        accs = eval_model_step(model, optimizer, scheduler, src_dataset, tgt_dataset, device, args)
        print(f"accs: {accs}")

        for i in range(5):
            list_acc[i].append(accs[i])
            if accs[i] > list_best_acc[i]:
                list_best_acc[i] = accs[i]

    list_acc = np.asarray(list_acc)
    # list_total_loss = np.asarray(list_total_loss)
    # list_ep_loss = np.asarray(list_ep_loss)
    list_losses = np.asarray(list_losses)

    epoch_report_target_test_best = np.argmax(list_acc[3])

    print(f"Best ACC:\n"
          f"best_acc_src_training: {list_best_acc[0]}\n"
          f"best_acc_src_validation: {list_best_acc[1]}\n"
          f"best_acc_src_testing: {list_best_acc[2]}\n"
          f"best_acc_target_validation: {list_best_acc[3]}\n"
          # f"best_acc_target_testing: {list_best_acc[4]}\n"
          f"best_acc_target_report: {list_acc[4][epoch_report_target_test_best]}")



    np.save('./main_v4_save/accs.npy', list_acc)
    # np.save('./main_v4_save/total_loss.npy', list_total_loss)
    # np.save('./main_v4_save/ep_loss.npy', list_ep_loss)
    np.save('./main_v4_save/losses.npy', list_losses)




def predict_new_links(model, zs, zt, topk=100):
    """
    Return top-K most likely cross-domain links.
    zs: [Ns, d], zt: [Nt, d]
    """
    model.eval()
    with torch.no_grad():
        # Compute all pairwise scores (use batch if too large)
        scores = torch.matmul(zs, zt.t())  # [Ns, Nt] — using dot product as score
        # Or use model's decoder:
        # Ns, Nt = zs.shape[0], zt.shape[0]
        # scores = torch.zeros(Ns, Nt)
        # for i in range(Ns):
        #     edge_feat = model.decode_edge_feat(zs[i].unsqueeze(0), zt)  # [Nt, d]
        #     scores[i] = torch.sigmoid(model.decode_score(edge_feat))

        # Flatten and get topk
        flat_scores = scores.flatten()
        topk_vals, topk_indices = torch.topk(flat_scores, k=topk)
        src_ids = topk_indices // zt.size(0)
        dst_ids = topk_indices % zt.size(0)
        print(f"topk_vals: {topk_vals} {topk_vals}")
        return src_ids, dst_ids, topk_vals



if __name__ == '__main__':
    args = arg_parse()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


    if args.dataset == "DBLP_ACM":
        source_dataset = pre_datasets.prepare_dblp_acm("./data_files", args.src_name)
        target_dataset = pre_datasets.prepare_dblp_acm("./data_files", args.tgt_name)
        print("DBLP_ACM")
        print(source_dataset.num_edges)

    # elif args.dataset == "Twitch":
    #     source_dataset = pre_datasets.prepare_Twitch("./data_files", args.src_name)
    #     target_dataset = pre_datasets.prepare_Twitch("./data_files", args.tgt_name)
    elif args.dataset == "WebKB":
        source_dataset = pre_datasets.prepare_WebKB("./data_files", args.src_name)
        target_dataset = pre_datasets.prepare_WebKB("./data_files", args.tgt_name)
    elif args.dataset == "Airports":
        source_dataset = pre_datasets.prepare_airports("./data_files/airports", args.src_name)
        target_dataset = pre_datasets.prepare_airports("./data_files/airports", args.tgt_name)

        source_train_mask, source_val_mask, source_test_mask = pre_datasets.random_mask(
            source_dataset.num_nodes,
            ratios=[0.6, 0.2, 0.2],
            seed=6
        )
        target_val_mask, target_test_mask = pre_datasets.random_mask(
            target_dataset.num_nodes,
            ratios=[0.2, 0.8],
            seed=7
        )

        source_dataset.source_training_mask = source_train_mask
        source_dataset.source_validation_mask = source_val_mask
        source_dataset.source_testing_mask = source_test_mask

        target_dataset.target_validation_mask = target_val_mask
        target_dataset.target_testing_mask = target_test_mask

    elif args.dataset == "Twitch":
        source_dataset = pre_datasets.load_twitch(target_path=f"{args.src_name}_target.csv", embedding_path=f"{args.src_name}_embedding.csv", edges_path=f"{args.src_name}_edges.csv")
        target_dataset = pre_datasets.load_twitch(target_path=f"{args.tgt_name}_target.csv", embedding_path=f"{args.tgt_name}_embedding.csv", edges_path=f"{args.tgt_name}_edges.csv")



    else:
        with open(f"../data_files/pileup/test_{args.train_sig}_PU{args.train_PU}_graph", "rb") as fp:
            source_dataset = pickle.load(fp)

        with open(f"../data_files/pileup/test_{args.test_sig}_PU{args.test_PU}_graph", "rb") as fp:
            target_dataset = pickle.load(fp)
        print("Pileup")

    # source_dataset = pre_datasets.prepare_dblp_acm("./data_files", 'acm')
    # target_dataset = pre_datasets.prepare_dblp_acm("./data_files", 'dblp')

    print(source_dataset.x.shape)
    print(target_dataset.x[1])
    # pa = input()


    in_dim = source_dataset.x.shape[1]
    cls_num = source_dataset.y.unique().shape[0]

    edge_predictor = CrossDomainLinkPredictor(in_dim)
    edge_predictor_t = CrossDomainLinkPredictor(in_dim)

    model = CrossNetwork(in_dim, cls_num, device, args)


    model_backbone_params = []
    model_special_params = []

    for name, param in model.named_parameters():
        if name == 'edge_weight_new':  # 精确匹配你的参数名
            model_special_params.append(param)
        else:
            model_backbone_params.append(param)


    edge_pred_params = list(edge_predictor.parameters()) + list(edge_predictor_t.parameters())

    optimizer = torch.optim.Adam([
        {'params': model_backbone_params, 'lr': args.lr},  # 主干网络
        {'params': model_special_params, 'lr': args.new_edge_lr},  # 新增边权重（标量）
        {'params': edge_pred_params, 'lr': args.ep_lr}  # edge predictor
    ])
    #--------------------------------------------------


    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=args.opt_decay_step, gamma=args.opt_decay_rate)

    seed = 5

    train(edge_predictor, edge_predictor_t, model, source_dataset, target_dataset, device, optimizer, scheduler, seed, args)



